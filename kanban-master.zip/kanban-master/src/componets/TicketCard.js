import React from 'react';

const cardStyles = {
  height: '100px', // Adjust height for a more rectangular shape
  maxWidth:"450px",
  minWidth:"350px",
  border: '1px solid #ccc',
  borderRadius: '8px',
  padding: '.8rem',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'flex-start',
  gap:".4rem",
  background:"white"
};

const coloredCircleStyles = {
  width: '30px',
  height: '30px',
  borderRadius: '50%',
  backgroundColor: 'red'
};

const iconsStyles = {
  width: '20px',
  height: '20px',
  borderRadius: '50%',
  backgroundColor: '#3498db'
};

const subtitleStyles = {
  fontSize: '.8rem',
  color:'#aaa',
  fontFamily:"Roboto"
};

const TicketCard = ({ticket}) => {
  return (
    <div style={cardStyles}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",border:"1px solid red"}}>
        <div style={{...subtitleStyles,fontSize:"1.2rem"}}>{ticket.id}</div>
        <div style={coloredCircleStyles}></div>
      </div>
      <div style={{display:"flex",justifyContent:"flex-start",alignItems:"center",border:"1px solid red",gap:"1rem"}}>
        <span><div style={{...iconsStyles,display:"inline-block",marginRight:".4rem"}}></div>{ticket.title}</span>
      </div>
      <div style={{display:"flex",alignItems:"center",border:"1px solid red",gap:"1rem"}}>
        <div style={{...iconsStyles,background:"green"}}></div>
        <div style={{display:"flex",justifyContent:"flex-start",alignItems:"center",border:"1px solid blue",gap:".2rem"}}>
          
          <div style={subtitleStyles}>{ticket?.tag.join(" ")}</div>
        </div>
      </div>
    </div>
  );
};

export default TicketCard;
