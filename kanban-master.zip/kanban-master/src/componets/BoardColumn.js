// src/BoardColumn.js
import React from 'react';
import TicketCard from './TicketCard';


const BoardColumn = ({ title, tickets , sortBy}) => {
      const groups = [...tickets].sort((t1,t2) => t1[sortBy]-t2[sortBy]) 
      console.log(title)
      console.log(groups)
  return (
    <div style={{border:"2px solid rgb(220, 220, 220)",boxShadow:"0 4px 8px rgba(0, 0, 0, 0.2)",borderRadius:".4rem",padding:"0 1rem",background:"#f3f3f3"}}>
      <h2>{title}</h2>  
      <div className="board-column" style={{display:"flex",flexDirection:"column",gap:"2rem"}}>    
        {
          groups.map((ticket) => (
          <TicketCard key={ticket.id} ticket={ticket} />
        ))}
      </div>
    </div>
  );
};

export default BoardColumn;
