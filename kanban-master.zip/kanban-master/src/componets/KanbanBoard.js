
import React, { useState, useEffect } from 'react';
import BoardColumn from './BoardColumn';
import { fetchData } from './api';
import { HiMiniAdjustmentsHorizontal } from "react-icons/hi2";
import { RiArrowDropDownLine } from "react-icons/ri";

const KanbanBoard = () => {
  const [selection,setSelection] = useState(true)
  const [tickets, setTickets] = useState([]);
  const [users, setUsers] = useState([]);
  const [groupingOption, setGroupingOption] = useState('status');
  const [sortOption, setSortOption] = useState('priority');

  useEffect(() => {
    fetchData().then((data) => {
      setTickets(data.tickets);
      setUsers(data.users);
    });
  }, []);
  
  const mapUserToTicket = () => {
    const priorityMap = ["No priority","Low","Medium","High","Urgent"]
    const combined = []
    tickets.forEach((ticket)=>{
      const connected = {...users.find((user)=> user.id===ticket.userId)}
      delete connected.id
      combined.push({...ticket,...connected,priority:priorityMap[ticket.priority]})})
    return combined
  }

  const groupTickets = () => {

    const groups = {}
    mapUserToTicket().forEach((ticket)=>{
      if(!groups[ticket[groupingOption]])
          {groups[ticket[groupingOption]] = [ticket] }
      else
          {groups[ticket[groupingOption]].push(ticket)}
    })

    return groups;
  };

  return (
    <div className="kanban-board" style={{position:"relative",display:"flex",flexDirection:"column"}}>
      <div className='Filter'>
          <div onClick={()=>{setSelection(!selection)}} style={{  margin:".4rem 1rem",
                                                                  width:"100px",
                                                                  display: "inline-flex",
                                                                  padding: ".4rem .4rem .6rem .4rem",
                                                                  fontSize: "1rem",
                                                                  fontWeight: "500",
                                                                  alignItems:"center",
                                                                  textAlign:"center",
                                                                  cursor: "pointer",
                                                                  border:"1.6px solid rgb(220, 220, 220)",
                                                                  boxShadow:"0 4px 8px rgba(0, 0, 0, 0.1)",
                                                                  backgroundColor: "#fff",
                                                                  justifyContent:"space-between",
                                                                  borderRadius: "5px",}}><HiMiniAdjustmentsHorizontal/><div>Display</div><RiArrowDropDownLine/></div>

          {selection && (    
            <div className='Selectors' style={{position:"absolute",border:"2px solid rgb(220, 220, 220)",boxShadow:"0 4px 8px rgba(0, 0, 0, 0.2)",margin:".4rem 1rem",padding:"1.2rem",display:"flex",flexDirection:"column",borderRadius:".8rem",width:"320px",gap:".4rem",zIndex:"10",background:"white"}}>
              <div className="sorting-options"  style={{display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
                <label style={{color:"GrayText"}}>Grouping</label>
                <select value={groupingOption} onChange={(e) => setGroupingOption(e.target.value)} style={{width:"120px",background:"white",borderRadius:".2rem",border:"1px solid black",padding:".3rem",fontFamily:"inherit",fontSize:"1em"}}>
                  <option value="priority">Priority</option>
                  <option value="name">Users</option>
                  <option value="status">Status</option>
                </select>
              </div>
              <div className="sorting-options" style={{display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
                <label style={{color:"GrayText"}}>Ordering</label>
                <select value={sortOption} onChange={(e) => setSortOption(e.target.value)}style={{width:"120px",background:"white",borderRadius:".2rem",border:"1px solid black",padding:".3rem",fontFamily:"inherit",fontSize:"1em"}}>
                  <option value="priority">Priority</option>
                  <option value="title">Title</option>
                </select>
              </div>
          </div>)
          }
      </div>
      
      <div className='Tickets' style={{display:"flex",justifyContent:"space-between",gap:"2rem"}}>
      {Object.entries(groupTickets()).map(([group, groupTickets]) => (
        <BoardColumn key={group} title={group} tickets={[...groupTickets]} sortBy={sortOption}/>
      ))}
      </div>
    </div>
  );
};

export default KanbanBoard;
