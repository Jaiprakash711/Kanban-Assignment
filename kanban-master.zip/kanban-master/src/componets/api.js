const apiUrl = 'https://api.quicksell.co/v1/internal/frontend-assignment';

export const fetchData = async () => {
const response = await fetch(apiUrl);
const data = await response.json();
return data;
}