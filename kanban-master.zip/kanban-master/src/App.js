import './App.css';
import KanbanBoard from './componets/KanbanBoard';

function App() {

  return (
    <div className="App">
    <KanbanBoard />
    </div>
  );
}

export default App;
